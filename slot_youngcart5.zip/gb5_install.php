<?php
// 기존 주소 호환용 진입점입니다. 신규 설치에는 gnuboard5_install.php를 사용하세요.
include_once('./gnuboard5_install.php');
